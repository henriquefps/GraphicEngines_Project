﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChickenFlee : MonoBehaviour
{
    GameObject myGameObject;
    GameObject player;
    Rigidbody gameObjectsRigidBody;
    private int hasArrived = 0;

    public static List<ChickenFlee> chickens = new List<ChickenFlee>();

    void Start()
    {
        if(SceneManager.GetActiveScene().buildIndex == 1) {
            chickens.Add(this);
        }
        else {
            chickens.Clear();
        }
        myGameObject = transform.root.gameObject;
        player = GameObject.Find("Temporary Player").transform.root.gameObject; 
        gameObjectsRigidBody = myGameObject.AddComponent<Rigidbody>();
        gameObjectsRigidBody.mass = 5;
    }

    void faceAwayFromPlayer(){
        transform.rotation = Quaternion.Slerp(transform.rotation,
        Quaternion.LookRotation((transform.position - player.transform.position).normalized), 10.0f * Time.deltaTime);
    }

    // Update is called once per frame

    void flee(int x){
        int speed = x;
        float dist = Vector3.Distance(player.transform.position, myGameObject.transform.position);
        if(dist < 4){
            GetComponentInChildren<Animator>().SetTrigger("PlayerIsNear");
            //transform.Translate(speed/(myGameObject.transform.position.x - player.transform.position.x) * Time.deltaTime, 0 ,speed/(myGameObject.transform.position.z - player.transform.position.z)  * Time.deltaTime);
            float auxy = transform.position.y;
            Vector3 direction = (transform.position - player.transform.position).normalized;
            transform.position += direction * 10.0f * Time.deltaTime;
            faceAwayFromPlayer();
        }
        else GetComponentInChildren<Animator>().SetTrigger("PlayerAway");
    }

    public float getDistanceFrom(Vector3 target){
        return Vector3.Distance(transform.position, target);
    }

    public void setHasArrived(){
        hasArrived = 1;
        GetComponentInChildren<Animator>().SetTrigger("ChickenArrived");
    }

    public int getHasArrived(){
        return hasArrived;
    }

    void Update()
    {
        if(hasArrived == 0)
        flee(10);
    }
}