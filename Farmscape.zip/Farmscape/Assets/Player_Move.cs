﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Move : MonoBehaviour
{
    float mul = 1;
    float speed_limitator = 0.6f;
    // Update is called once per frame

    void RunOnShift(){
        if(Input.GetKeyDown(KeyCode.LeftShift)){
            mul = 2;
        }else if(Input.GetKeyUp(KeyCode.LeftShift)){
            mul = 1;
        }
    }

    void Move(){
        float translationZ = Input.GetAxis("Vertical") * 10.0f;
        float translationX = Input.GetAxis("Horizontal") * 10.0f;

        translationZ *= Time.deltaTime * speed_limitator * mul;
        translationX *= Time.deltaTime * speed_limitator;
        transform.Translate(translationX,0,translationZ);
    }

    void Rotate(){
        float rotateMouseY = 100.0f * Input.GetAxis("Mouse X") * Time.deltaTime;
        transform.Rotate(0,rotateMouseY,0);
    }

    void Update()
    {
        RunOnShift();
        Move();
        Rotate();
    }

    
}