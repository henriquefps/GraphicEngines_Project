﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Move : MonoBehaviour
{
    float speed_limitator = 0.6f;
    // Update is called once per frame
    void Update()
    {
        float translationX = Input.GetAxis("Vertical") * 10.0f;
        float translationY = Input.GetAxis("Horizontal") * 10.0f;
        translationX *= Time.deltaTime * speed_limitator;
        translationY *= Time.deltaTime * speed_limitator;

        transform.Translate(translationY,0,translationX);
    }

    
}