﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HorseScript : MonoBehaviour
{
    GameObject myGameObject;
    GameObject player;
    int isFollowing = 0;
    int hasArrived = 0;
    
    public static List<HorseScript> horses = new List<HorseScript>();

    void Start()
    {
        if(SceneManager.GetActiveScene().buildIndex == 1) {
            horses.Add(this);
        }
        else {
            horses.Clear();
        }
        print(horses.Count);
        myGameObject = transform.root.gameObject;
        player = GameObject.Find("Temporary Player").transform.root.gameObject; 
    }

    float rotationAngle(Vector3 a, Vector3 b){
        float x = a.x *b.x + a.z * b.z;
        float y = (a.x*a.x + a.z*a.z) * (b.x*b.x + b.z*b.z);
        return x/y;
    }

    void facePlayer(){
        transform.rotation = Quaternion.Slerp(transform.rotation,
        Quaternion.LookRotation((player.transform.position - transform.position).normalized), 10.0f * Time.deltaTime);
    }

    void seek(int speed, float minDist){
        float dist = Vector3.Distance(player.transform.position, myGameObject.transform.position);
        if(dist < minDist && dist > 2.5f){
            GetComponent<Animator>().SetTrigger("PlayerIsNear");
            float auxy = transform.position.y;
            Vector3 direction = (player.transform.position - transform.position).normalized;
            transform.position += direction * 10.0f * Time.deltaTime;
            facePlayer();
        }
        else GetComponent<Animator>().SetTrigger("PlayerAway");
    }
    
    // Update is called once per frame
    void Update()
    {
        if(hasArrived == 0){
            if(Vector3.Distance(player.transform.position, myGameObject.transform.position) < 3.0f && Input.GetKeyDown(KeyCode.Space)){
                if(isFollowing == 0) {
                    isFollowing = 1;
                } else isFollowing = 0;
            }
            if(isFollowing == 1) {
                seek(10, 5.0f);
            }
        }
    }

    public float getDistanceFrom(Vector3 target){
        return Vector3.Distance(transform.position, target);
    }

    public void setHasArrived(){
        hasArrived = 1;
        GetComponent<Animator>().SetTrigger("HorseArrived");
    }

    public int getHasArrived(){
        return hasArrived;
    }
}
