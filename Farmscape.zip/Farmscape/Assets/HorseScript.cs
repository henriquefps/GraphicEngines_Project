﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HorseScript : MonoBehaviour
{
    GameObject myGameObject;
    GameObject player;
    Rigidbody gameObjectsRigidBody;

    // Start is called before the first frame update
    void Start()
    {
        myGameObject = transform.root.gameObject;
        player = GameObject.Find("Temporary Player").transform.root.gameObject; gameObjectsRigidBody = myGameObject.AddComponent<Rigidbody>();
        gameObjectsRigidBody.mass = 5; 
    }

    int isFollowing = 0;

    float rotationAngle(Vector3 a, Vector3 b){
        float x = a.x *b.x + a.z * b.z;
        float y = (a.x*a.x + a.z*a.z) * (b.x*b.x + b.z*b.z);
        return x/y;
    }

    void facePlayer(){
        transform.rotation = Quaternion.Slerp(transform.rotation,
        Quaternion.LookRotation((player.transform.position - transform.position).normalized), 10.0f * Time.deltaTime);
    }

    void seek(int speed, float minDist){
        float dist = Vector3.Distance(player.transform.position, myGameObject.transform.position);
        if(dist < minDist){
            GetComponent<Animator>().SetTrigger("PlayerIsNear");
            transform.Translate((player.transform.position.x - myGameObject.transform.position.x) * Time.deltaTime, 0 , (player.transform.position.z - myGameObject.transform.position.z) * Time.deltaTime);
            facePlayer();
        }
        else GetComponent<Animator>().SetTrigger("PlayerAway");
    }
    // Update is called once per frame
    void Update()
    {
        if(Vector3.Distance(player.transform.position, myGameObject.transform.position) < 3.0f && Input.GetKeyDown(KeyCode.Space)){
            print("oi");
            if(isFollowing == 0) {
                isFollowing = 1;
            } else isFollowing = 0;
        }
        if(isFollowing == 1) {
            seek(10, 5.0f);
        }
    }
}
