﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.SceneManagement;

public class GameControllerScript : MonoBehaviour
{   
    GameObject chickensArea; 
    GameObject horseArea1;
    List<ChickenFlee> chickens;
    List<HorseScript> horses;
    
    void Start(){
        chickens = ChickenFlee.chickens;
        horses = HorseScript.horses;
        chickensArea = GameObject.Find("Grown_Chicken_Spot").transform.root.gameObject;
        horseArea1 = GameObject.Find("HorseSpot").transform.root.gameObject;
    }

    // Update is called once per frame
    void Update(){
        int auxChickens = 0;
        int auxHorses = 0;
        for(int i = 0; i < chickens.Count; i++){
            if(chickens.ElementAt(i).getDistanceFrom(chickensArea.transform.position) < 3.0f){
                chickens.ElementAt(i).setHasArrived();
            }
            if(chickens.ElementAt(i).getHasArrived() == 1)
                auxChickens++;
        }
        for(int i = 0; i < horses.Count; i++){
            if(horses.ElementAt(i).getDistanceFrom(horseArea1.transform.position) < 2.5f){
                horses.ElementAt(i).setHasArrived();
            }
            if(horses.ElementAt(i).getHasArrived() == 1)
                auxHorses++;
        }

        if(auxChickens == chickens.Count && auxHorses == horses.Count) {
            chickens.Clear();
            horses.Clear();
            SceneManager.LoadScene(0);
        }
        else{
            print(chickens.Count - auxChickens);
            print(horses.Count - auxHorses);
        }


    }
}
