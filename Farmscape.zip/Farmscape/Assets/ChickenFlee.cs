﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChickenFlee : MonoBehaviour
{
    GameObject myGameObject;
    GameObject player;
    Rigidbody gameObjectsRigidBody;

    void Start()
    {
        myGameObject = transform.root.gameObject;
        player = GameObject.Find("Temporary Player").transform.root.gameObject; gameObjectsRigidBody = myGameObject.AddComponent<Rigidbody>();
        gameObjectsRigidBody.mass = 5; 
        
    }

    // Update is called once per frame
    int speed = 10;
    void Update()
    {
        float dist = Vector3.Distance(player.transform.position, myGameObject.transform.position);
        if(dist < 6){
            GetComponentInChildren<Animator>().SetTrigger("PlayerIsNear");
            transform.Translate(speed/(myGameObject.transform.position.x - player.transform.position.x)* Time.deltaTime, 0 ,speed/(myGameObject.transform.position.z - player.transform.position.z)  * Time.deltaTime);
        }
        else GetComponentInChildren<Animator>().SetTrigger("PlayerAway");
    }
}