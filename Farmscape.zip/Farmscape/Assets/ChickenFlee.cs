﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChickenFlee : MonoBehaviour
{
    GameObject myGameObject;
    GameObject player;
    Rigidbody gameObjectsRigidBody;

    List<GameObject> chickens = new List<GameObject>();

    void Start()
    {
        myGameObject = transform.root.gameObject;
        for (int i = 1; i < 10; i++)
        {
            chickens.Add(GameObject.Find("Chicken"+i).transform.root.gameObject);
        
        }
        player = GameObject.Find("Temporary Player").transform.root.gameObject; 
        gameObjectsRigidBody = myGameObject.AddComponent<Rigidbody>();
        gameObjectsRigidBody.mass = 5; 
        
    }

    void faceAwayFromPlayer(){
        transform.rotation = Quaternion.Slerp(transform.rotation,
        Quaternion.LookRotation((transform.position - player.transform.position).normalized), 10.0f * Time.deltaTime);
    }

    // Update is called once per frame

    void flee(int x){
        int speed = x;
        float dist = Vector3.Distance(player.transform.position, myGameObject.transform.position);
        if(dist < 4){
            GetComponentInChildren<Animator>().SetTrigger("PlayerIsNear");
            //transform.Translate(speed/(myGameObject.transform.position.x - player.transform.position.x) * Time.deltaTime, 0 ,speed/(myGameObject.transform.position.z - player.transform.position.z)  * Time.deltaTime);
            float auxy = transform.position.y;
            Vector3 direction = (transform.position - player.transform.position).normalized;
            transform.position += direction * 10.0f * Time.deltaTime;
            faceAwayFromPlayer();
        }
        else GetComponentInChildren<Animator>().SetTrigger("PlayerAway");
    }

    

    void groupChickens(){
        for(int i = 0; i < 9; i++){

        }
    }

    void Update()
    {
        flee(10);
    }
}